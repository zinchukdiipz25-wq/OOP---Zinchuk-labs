using System;
using System.Text;

namespace IndependentWork1;

public class Program
{
    public static void Main(string[] args)
    {
        Console.OutputEncoding = Encoding.UTF8;
        Book book = new Book("Чистий код", 464);
        Bicycle bicycle = new Bicycle("Trek", 18);
        WaterTank tank = new WaterTank(100, 35);

        Console.WriteLine($"Книга: {book.Title}, сторінок: {book.Pages}, довга: {book.IsLongBook()}");
        book.Title = "Алгоритми";
        Console.WriteLine($"Нова назва книги: {book.Title}");
        Console.WriteLine($"Велосипед: {bicycle.Brand}, швидкість після прискорення: {bicycle.Accelerate(7)} км/год");
        Console.WriteLine($"Бак: місткість {tank.Capacity} л, після доливання: {tank.Fill(20)} л");
    }
}

public class Book
{
    private string _title;
    private int _pages;
    public string Title { get => _title; set => _title = value; }
    public int Pages => _pages;
    public Book(string title, int pages) { _title = title; _pages = pages; }
    public bool IsLongBook() => _pages > 300;
}

public class Bicycle
{
    private string _brand;
    private int _speed;
    public string Brand { get => _brand; set => _brand = value; }
    public int Speed => _speed;
    public Bicycle(string brand, int speed) { _brand = brand; _speed = speed; }
    public int Accelerate(int amount) { _speed += amount; return _speed; }
}

public class WaterTank
{
    private int _capacity;
    private int _waterLevel;
    public int Capacity { get => _capacity; set => _capacity = value; }
    public int WaterLevel => _waterLevel;
    public WaterTank(int capacity, int waterLevel) { _capacity = capacity; _waterLevel = waterLevel; }
    public int Fill(int liters) { _waterLevel = Math.Min(_capacity, _waterLevel + liters); return _waterLevel; }
}
