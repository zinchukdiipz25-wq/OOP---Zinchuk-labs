using System;
using System.Collections.Generic;

namespace IndependentWork2;

public class Product
{
    public string Name { get; }
    public decimal Price { get; }
    public Product(string name, decimal price) { Name = name; Price = price; }
}

public class Cart
{
    private readonly List<(Product Product, int Quantity)> _items = new();
    public void AddItem(Product product, int quantity) => _items.Add((product, quantity));
    public decimal ApplyDiscount(Product product, decimal lineTotal) => product.Price > 500m ? lineTotal * 0.9m : lineTotal;
    public decimal GetTotal()
    {
        decimal total = 0;
        foreach (var item in _items)
            total += ApplyDiscount(item.Product, item.Product.Price * item.Quantity);
        return total;
    }
    public void PrintItems()
    {
        foreach (var item in _items)
        {
            decimal line = item.Product.Price * item.Quantity;
            decimal discounted = ApplyDiscount(item.Product, line);
            Console.WriteLine($"{item.Product.Name}: {line:F2} грн; знижка: {line - discounted:F2} грн; до сплати: {discounted:F2} грн");
        }
    }
}

public static class ObjectOrientedDemo
{
    public static decimal Run()
    {
        Cart cart = new Cart();
        cart.AddItem(new Product("Навушники", 800m), 2);
        cart.AddItem(new Product("Клавіатура", 1200m), 1);
        cart.AddItem(new Product("Кабель", 150m), 3);
        cart.PrintItems();
        Console.WriteLine($"Разом: {cart.GetTotal():F2} грн");
        return cart.GetTotal();
    }
}
