using System;

namespace IndependentWork2;

// Проблеми процедурного підходу:
// 1. Назви, ціни та кількості одного товару розкидані по різних масивах.
// 2. Масиви можуть мати різну довжину, що спричинить помилки індексації.
// 3. Для іншого кошика потрібно знову передавати всі масиви у функції.
public static class ProceduralDemo
{
    public static decimal CalculateLineTotal(decimal price, int quantity) => price * quantity;
    public static decimal ApplyDiscount(decimal price, decimal lineTotal) => price > 500m ? lineTotal * 0.9m : lineTotal;
    public static decimal CalculateCartTotal(decimal[] prices, int[] quantities)
    {
        decimal total = 0;
        for (int i = 0; i < prices.Length; i++)
            total += ApplyDiscount(prices[i], CalculateLineTotal(prices[i], quantities[i]));
        return total;
    }
    public static decimal Run()
    {
        string[] names = { "Навушники", "Клавіатура", "Кабель" };
        decimal[] prices = { 800m, 1200m, 150m };
        int[] quantities = { 2, 1, 3 };
        for (int i = 0; i < names.Length; i++)
        {
            decimal line = CalculateLineTotal(prices[i], quantities[i]);
            decimal discounted = ApplyDiscount(prices[i], line);
            Console.WriteLine($"{names[i]}: {line:F2} грн; знижка: {line - discounted:F2} грн; до сплати: {discounted:F2} грн");
        }
        decimal total = CalculateCartTotal(prices, quantities);
        Console.WriteLine($"Разом: {total:F2} грн");
        return total;
    }
}
