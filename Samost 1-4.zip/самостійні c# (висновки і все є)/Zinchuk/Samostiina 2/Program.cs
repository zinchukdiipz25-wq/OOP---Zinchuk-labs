using System;
using System.Text;

namespace IndependentWork2;
public class Program
{
    public static void Main(string[] args)
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.WriteLine("ПРОЦЕДУРНИЙ ПІДХІД");
        decimal proceduralTotal = ProceduralDemo.Run();
        Console.WriteLine("\nОБ'ЄКТНИЙ ПІДХІД");
        decimal objectTotal = ObjectOrientedDemo.Run();
        Console.WriteLine($"\nПідсумки однакові: {proceduralTotal == objectTotal}");
    }
}
