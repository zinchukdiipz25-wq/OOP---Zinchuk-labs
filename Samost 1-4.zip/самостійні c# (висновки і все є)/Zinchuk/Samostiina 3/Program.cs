using System;
using System.Runtime.CompilerServices;
using System.Text;

namespace sw3v7;

public class SerialPortConnection : IDisposable
{
    private readonly string _portName;
    private bool _isPortOpen;
    private bool _disposed;

    public string PortName => _portName;
    public bool IsPortOpen => _isPortOpen;

    public SerialPortConnection(string portName)
    {
        _portName = portName;
        _isPortOpen = true;
        Console.WriteLine($"Порт {_portName} відкрито.");
    }

    public void SendData(byte[] data)
    {
        if (_disposed || !_isPortOpen) throw new ObjectDisposedException(nameof(SerialPortConnection));
        Console.WriteLine($"Надіслано {data.Length} байт через {_portName}.");
    }

    protected virtual void Dispose(bool disposing)
    {
        if (_disposed) return;
        if (disposing)
        {
            // Тут звільнялися б керовані ресурси, якби вони були.
        }
        if (_isPortOpen)
        {
            Console.WriteLine($"Порт {_portName} закрито (звільнення ресурсу).");
            _isPortOpen = false;
        }
        _disposed = true;
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    ~SerialPortConnection() => Dispose(false);
}

public class Program
{
    public static void Main(string[] args)
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.WriteLine("=== 1. using ===");
        using (var port = new SerialPortConnection("COM1"))
        {
            port.SendData(new byte[] { 1, 2, 3 });
        }

        Console.WriteLine("\n=== 2. Явний Dispose() ===");
        var manualPort = new SerialPortConnection("COM2");
        manualPort.SendData(new byte[] { 4, 5 });
        manualPort.Dispose();
        manualPort.Dispose(); // Повторне звільнення не має ефекту.

        Console.WriteLine("\n=== 3. Фіналізатор і GC ===");
        CreateUnreleasedPort();
        Console.WriteLine("Викликаємо GC.Collect()...");
        GC.Collect();
        GC.WaitForPendingFinalizers();
        Console.WriteLine("Фіналізацію завершено.");
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private static void CreateUnreleasedPort()
    {
        var port = new SerialPortConnection("COM3");
        port.SendData(new byte[] { 6 });
        // Dispose навмисно не викликається для демонстрації фіналізатора.
    }
}
