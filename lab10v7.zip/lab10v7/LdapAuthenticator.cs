namespace lab10v7;

public class LdapAuthenticator : Authenticator
{
    // Імітація каталогу користувачів LDAP
    private readonly Dictionary<string, string> _directory = new()
    {
        ["ivan"] = "ldap2026",
        ["olena"] = "ldap2027"
    };

    public override bool Authenticate(string username, string password)
    {
        bool success = _directory.TryGetValue(username, out var storedPassword)
                       && storedPassword == password;

        LogAttempt(username, success);
        return success;
    }
}