namespace lab10v7;

public class SmsNotifier : INotifier
{
    public string PhoneNumber { get; }

    public SmsNotifier(string phoneNumber)
    {
        PhoneNumber = phoneNumber;
    }

    public void SendNotification(string message)
    {
        Console.WriteLine($"[SMS -> {PhoneNumber}] {message}");
    }
}