namespace lab10v7;

public class DatabaseAuthenticator : Authenticator
{
    // Імітація таблиці користувачів у базі даних
    private readonly Dictionary<string, string> _users = new()
    {
        ["admin"] = "admin123",
        ["dmytro"] = "qwerty"
    };

    public override bool Authenticate(string username, string password)
    {
        bool success = _users.TryGetValue(username, out var storedPassword)
                       && storedPassword == password;

        LogAttempt(username, success);
        return success;
    }
}