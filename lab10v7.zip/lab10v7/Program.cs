﻿using lab10v7;

// ---------- Поліморфізм через інтерфейс INotifier ----------
Console.WriteLine("=== Сповіщення (INotifier) ===");

List<INotifier> notifiers = new()
{
    new EmailNotifier("student@example.com"),
    new SmsNotifier("+380501234567")
};

foreach (INotifier notifier in notifiers)
{
    notifier.SendNotification("Вітаємо! Ваш акаунт створено.");
}

// ---------- Поліморфізм через абстрактний клас Authenticator ----------
Console.WriteLine("\n=== Автентифікація (Authenticator) ===");

List<Authenticator> authenticators = new()
{
    new DatabaseAuthenticator(),
    new LdapAuthenticator()
};

foreach (Authenticator auth in authenticators)
{
    Console.WriteLine($"\n{auth.GetType().Name}:");

    bool r1 = auth.Authenticate("admin", "admin123");
    Console.WriteLine($"  admin/admin123 -> {r1}");

    bool r2 = auth.Authenticate("ivan", "ldap2026");
    Console.WriteLine($"  ivan/ldap2026  -> {r2}");

    bool r3 = auth.Authenticate("admin", "wrong");
    Console.WriteLine($"  admin/wrong    -> {r3}");
}