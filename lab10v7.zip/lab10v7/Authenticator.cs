namespace lab10v7;

public abstract class Authenticator
{
    // Абстрактний метод: кожен нащадок перевіряє дані по-своєму
    public abstract bool Authenticate(string username, string password);

    // Конкретний метод: спільна логіка для всіх нащадків
    public void LogAttempt(string username, bool success)
    {
        string result = success ? "успішно" : "невдало";
        Console.WriteLine($"  [{DateTime.Now:HH:mm:ss}] Спроба входу '{username}': {result}");
    }
}