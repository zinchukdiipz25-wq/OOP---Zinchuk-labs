namespace lab10v7;

public interface INotifier
{
    void SendNotification(string message);
}