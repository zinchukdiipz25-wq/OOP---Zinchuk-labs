namespace lab10v7;

public class EmailNotifier : INotifier
{
    public string Address { get; }

    public EmailNotifier(string address)
    {
        Address = address;
    }

    public void SendNotification(string message)
    {
        Console.WriteLine($"[Email -> {Address}] {message}");
    }
}