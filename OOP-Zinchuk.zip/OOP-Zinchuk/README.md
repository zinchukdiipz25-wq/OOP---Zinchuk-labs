# Лабораторна робота №7. Generics, IRepository, юніт-тести

Варіант 7. Сутність `Department` (Name, Location).

## Структура

- `lab12v7/IEntity.cs` - інтерфейс з властивістю `int Id { get; set; }`.
- `lab12v7/Department.cs` - сутність варіанту: `Id`, `Name`, `Location`; реалізує `IEntity`.
- `lab12v7/IRepository.cs` - `IRepository<T> where T : class, IEntity` з методами
  `GetById`, `GetAll`, `Add`, `Update`, `Delete`.
- `lab12v7/InMemoryRepository.cs` - реалізація на основі `List<T>`.
  `GetById` повертає `null` для неіснуючого Id; `Update`/`Delete` кидають
  `KeyNotFoundException`; `Add` кидає `ArgumentException` при дублі Id.
- `lab12v7/Program.cs` - демонстрація CRUD у консолі.
- `lab12v7.Tests/InMemoryRepositoryTests.cs` - xUnit-тести для всіх методів,
  включно з неіснуючими елементами.

## Запуск

```
dotnet run --project lab12v7
dotnet test
```
