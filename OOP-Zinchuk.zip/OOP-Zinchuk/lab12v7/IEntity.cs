namespace lab12v7;

/// <summary>
/// Базовий інтерфейс для всіх сутностей, які можна зберігати в репозиторії.
/// </summary>
public interface IEntity
{
    int Id { get; set; }
}
