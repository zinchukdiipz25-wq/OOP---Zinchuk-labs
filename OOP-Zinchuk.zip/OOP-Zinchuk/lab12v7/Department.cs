namespace lab12v7;

/// <summary>
/// Сутність варіанту 7: Department (Name, Location).
/// </summary>
public class Department : IEntity
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Location { get; set; } = string.Empty;

    public Department() { }

    public Department(int id, string name, string location)
    {
        Id = id;
        Name = name;
        Location = location;
    }

    public override string ToString()
    {
        return $"Department #{Id}: {Name} ({Location})";
    }
}
