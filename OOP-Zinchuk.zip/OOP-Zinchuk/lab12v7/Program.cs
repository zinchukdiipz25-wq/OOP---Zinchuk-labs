using lab12v7;

var repo = new InMemoryRepository<Department>();

Console.WriteLine("=== Додавання ===");
repo.Add(new Department { Name = "IT", Location = "Корпус 1" });
repo.Add(new Department { Name = "Бухгалтерія", Location = "Корпус 2" });
repo.Add(new Department { Name = "Кадри", Location = "Корпус 2" });
PrintAll(repo);

Console.WriteLine("\n=== Отримання за Id ===");
Console.WriteLine(repo.GetById(2));
Console.WriteLine(repo.GetById(99) == null
    ? "Елемент з Id = 99 не знайдено (null)"
    : "Помилка: елемент знайдено");

Console.WriteLine("\n=== Оновлення ===");
repo.Update(new Department { Id = 1, Name = "IT-відділ", Location = "Корпус 3" });
Console.WriteLine(repo.GetById(1));

try
{
    repo.Update(new Department { Id = 99, Name = "Немає", Location = "-" });
}
catch (KeyNotFoundException ex)
{
    Console.WriteLine("Помилка оновлення: " + ex.Message);
}

Console.WriteLine("\n=== Видалення ===");
repo.Delete(2);
PrintAll(repo);

try
{
    repo.Delete(99);
}
catch (KeyNotFoundException ex)
{
    Console.WriteLine("Помилка видалення: " + ex.Message);
}

static void PrintAll(IRepository<Department> repo)
{
    foreach (var d in repo.GetAll())
        Console.WriteLine(d);
}
