namespace lab12v7;

/// <summary>
/// Узагальнений репозиторій. T обмежений: має бути класом і реалізовувати IEntity.
/// </summary>
public interface IRepository<T> where T : class, IEntity
{
    /// <summary>Повертає елемент за Id або null, якщо такого немає.</summary>
    T? GetById(int id);

    /// <summary>Повертає всі елементи.</summary>
    IEnumerable<T> GetAll();

    /// <summary>Додає елемент. Якщо Id == 0, Id призначається автоматично.</summary>
    void Add(T item);

    /// <summary>Оновлює існуючий елемент (пошук за Id).</summary>
    void Update(T item);

    /// <summary>Видаляє елемент за Id.</summary>
    void Delete(int id);
}
