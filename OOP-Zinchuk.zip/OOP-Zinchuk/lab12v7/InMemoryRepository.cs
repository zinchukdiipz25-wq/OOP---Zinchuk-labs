namespace lab12v7;

/// <summary>
/// Реалізація IRepository, що зберігає дані в пам'яті (List&lt;T&gt;).
/// </summary>
public class InMemoryRepository<T> : IRepository<T> where T : class, IEntity
{
    private readonly List<T> _items = new();
    private int _nextId = 1;

    public T? GetById(int id)
    {
        return _items.FirstOrDefault(x => x.Id == id);
    }

    public IEnumerable<T> GetAll()
    {
        // повертаємо копію, щоб зовнішній код не змінював внутрішній список
        return _items.ToList();
    }

    public void Add(T item)
    {
        if (item == null)
            throw new ArgumentNullException(nameof(item));

        if (item.Id == 0)
        {
            item.Id = _nextId;
        }
        else if (_items.Any(x => x.Id == item.Id))
        {
            throw new ArgumentException($"Елемент з Id = {item.Id} уже існує.", nameof(item));
        }

        _items.Add(item);
        _nextId = Math.Max(_nextId, item.Id) + 1;
    }

    public void Update(T item)
    {
        if (item == null)
            throw new ArgumentNullException(nameof(item));

        int index = _items.FindIndex(x => x.Id == item.Id);
        if (index < 0)
            throw new KeyNotFoundException($"Елемент з Id = {item.Id} не знайдено.");

        _items[index] = item;
    }

    public void Delete(int id)
    {
        T? existing = GetById(id);
        if (existing == null)
            throw new KeyNotFoundException($"Елемент з Id = {id} не знайдено.");

        _items.Remove(existing);
    }
}
